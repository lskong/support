#!/bin/sh

cp cfssl_1.5.0_linux_amd64 /usr/local/bin/cfssl
cp cfssljson_1.5.0_linux_amd64 /usr/local/bin/cfssljson
cp cfssl-certinfo_1.5.0_linux_amd64 /usr/local/bin/cfssl-certinfo

chmod +x /usr/local/bin/cfssl*